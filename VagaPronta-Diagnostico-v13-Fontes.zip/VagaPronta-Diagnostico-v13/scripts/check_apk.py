import sys, zipfile
from pathlib import Path
apk=Path(sys.argv[1]); assert apk.stat().st_size > 2000
with zipfile.ZipFile(apk) as z:
    assert z.testzip() is None
    files = set(z.namelist())
    assert 'AndroidManifest.xml' in files and 'classes.dex' in files
    assert z.read('classes.dex').startswith(b'dex\n')
print('Estrutura ZIP/DEX do APK aprovada (assinatura verificada separadamente por apksigner).')
