package de.deat.vagapronta.diagnostico;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import javax.net.ssl.HttpsURLConnection;

/**
 * Native HTTP diagnostics. No WebView, accessibility service, authentication tokens or booking POSTs.
 * Requests run only after an explicit button press and never on the main/UI thread.
 */
public final class MainActivity extends Activity {
    private static final String ORIGIN = "https://api.bookkercorp.com";
    private TextView output;
    private EditText email;
    private EditText domain;
    private Button btnPing;
    private Button btnSSO;
    private Button btnDomain;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showUi();
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private TextView label(String text, int size) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setPadding(0, dp(7), 0, dp(7));
        return view;
    }

    private void showUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(35), dp(18), dp(28));
        scroll.addView(root);

        root.addView(label("Vaga Pronta — diagnostico 1.3", 21));
        root.addView(label("Conexao real com a API Bookker, sem raspa-tela. Nenhuma reserva sera criada.", 14));

        btnPing = new Button(this);
        btnPing.setText("Testar HTTPS Bookker");
        root.addView(btnPing);

        root.addView(label("E-mail corporativo (enviado somente quando voce tocar no botao SSO)", 13));
        email = new EditText(this);
        email.setSingleLine(true);
        email.setHint("usuario@empresa.com");
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        root.addView(email);
        btnSSO = new Button(this);
        btnSSO.setText("Identificar SSO");
        root.addView(btnSSO);

        root.addView(label("Dominio da empresa (ex.: empresa.com)", 13));
        domain = new EditText(this);
        domain.setSingleLine(true);
        domain.setHint("empresa.com");
        domain.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        root.addView(domain);
        btnDomain = new Button(this);
        btnDomain.setText("Consultar dominio corporativo");
        root.addView(btnDomain);

        output = label("Pronto para iniciar. Nenhum pedido enviado.", 15);
        output.setTextIsSelectable(true);
        root.addView(output);
        root.addView(label("Diagnostico: HTTPS sem usuario/senha/token. Uma resposta HTTP 401/403 indica que o servidor respondeu, mas nao concede acesso. Erros do servidor nao significam reserva.", 12));
        setContentView(scroll);

        btnPing.setOnClickListener(v -> request("Conectividade", "GET", "/api/v1/users/me/resourceswithaccess", null));
        btnSSO.setOnClickListener(v -> {
            String value = email.getText().toString().trim();
            if (!value.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$") || value.length() > 254) {
                output.setText("Informe um e-mail corporativo valido.");
                return;
            }
            try {
                String json = new JSONObject().put("email", value).toString();
                request("SSO", "POST", "/api/v1/auth/domains", json);
            } catch (Exception e) {
                output.setText("Erro ao preparar pedido.");
            }
        });
        btnDomain.setOnClickListener(v -> {
            String value = domain.getText().toString().trim().toLowerCase(Locale.ROOT);
            if (!value.matches("^[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?$") || !value.contains(".")) {
                output.setText("Informe somente o dominio (sem https://).");
                return;
            }
            try {
                String json = new JSONObject().put("domain", value).toString();
                request("Dominio", "POST", "/api/v1/auth/endpoint", json);
            } catch (Exception e) {
                output.setText("Erro ao preparar pedido.");
            }
        });
    }

    private void setBusy(boolean value) {
        btnPing.setEnabled(!value);
        btnSSO.setEnabled(!value);
        btnDomain.setEnabled(!value);
    }

    private void request(String label, String method, String path, String jsonBody) {
        setBusy(true);
        output.setText("Consultando API Bookker (" + label + ")...");
        new Thread(() -> {
            final String result = execute(label, method, path, jsonBody);
            runOnUiThread(() -> { if (!isFinishing() && !isDestroyed()) { output.setText(result); setBusy(false); } });
        }, "bookker-diagnostic").start();
    }

    private String execute(String label, String method, String path, String jsonBody) {
        HttpsURLConnection connection = null;
        try {
            URL url = new URL(ORIGIN + path);
            if (!"https".equals(url.getProtocol()) || !"api.bookkercorp.com".equals(url.getHost())) {
                return "Endereco recusado.";
            }
            connection = (HttpsURLConnection) url.openConnection();
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(12000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod(method);
            connection.setRequestProperty("Accept", "application/json");
            if (jsonBody != null) {
                byte[] bytes = jsonBody.getBytes(StandardCharsets.UTF_8);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setFixedLengthStreamingMode(bytes.length);
                try (java.io.OutputStream out = connection.getOutputStream()) { out.write(bytes); }
            }
            int status = connection.getResponseCode();
            String message = label + " — HTTP " + status + "\n";
            if (status == 401 || status == 403) return message + "Servidor respondeu; autenticacao/autorizacao necessaria.";
            if (status >= 300 && status < 400) return message + "Redirecionamento. Nao seguido por seguranca.";
            if (status == 404) return message + "Servidor respondeu; rota nao encontrada nesta API.";
            if (status >= 500) return message + "Servidor respondeu com erro interno.";
            if ("SSO".equals(label) && status >= 200 && status < 300) {
                try (java.io.InputStream stream = connection.getInputStream()) {
                    byte[] bytes = new byte[4096];
                    int count = stream.read(bytes);
                    if (count > 0) {
                        JSONObject response = new JSONObject(new String(bytes, 0, count, StandardCharsets.UTF_8));
                        // Deliberately display only the authType field, never full payloads or tokens.
                        String type = response.optString("authType", "nao informado");
                        if (type.length() > 70) type = type.substring(0, 70);
                        return message + "authType: " + type;
                    }
                } catch (Exception ignored) {
                    return message + "Resposta recebida; formato SSO nao identificado.";
                }
            }
            return message + "Servidor respondeu. Nenhuma reserva realizada.";
        } catch (java.net.UnknownHostException e) {
            return label + " — erro de DNS: servidor nao localizado.";
        } catch (javax.net.ssl.SSLException e) {
            return label + " — falha de certificado ou conexao TLS.";
        } catch (java.net.SocketTimeoutException e) {
            return label + " — tempo limite atingido.";
        } catch (IOException e) {
            return label + " — erro de rede (" + e.getClass().getSimpleName() + ").";
        } catch (Exception e) {
            return label + " — erro interno de diagnostico (" + e.getClass().getSimpleName() + ").";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
