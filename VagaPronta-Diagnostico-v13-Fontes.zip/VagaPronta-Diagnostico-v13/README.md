# Vaga Pronta 1.3 — diagnostico Android nativo

Este pacote contém o código-fonte Java de um aplicativo Android que tenta consultar **HTTPS real** no servidor `api.bookkercorp.com`, com resposta exibida na tela. Ele não extrai sessão do Bookker, não usa a tela do Bookker, não faz login Microsoft e **não tenta reservar vagas**. Serve exclusivamente para diagnosticar comunicação e resposta do servidor em seu dispositivo.

## Compilar com SDK oficial

O código usa Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, Android SDK 35, build-tools 35.0.0. Execute `gradle --no-daemon :app:assembleDebug` neste diretório ou use GitHub Actions.

## Publicar em repositório GitHub novo pelo navegador do celular

1. Crie um repositório novo e vazio, por exemplo `VagaPronta-Android` (deixe privado se preferir).
2. Envie o arquivo `VagaPronta-Diagnostico-v13-Fontes.zip` para a **raiz** do repositório (não precisa extrair).
3. No editor de arquivos do GitHub, crie `.github/workflows/build-vagapronta.yml` usando o arquivo `build-vagapronta.yml` fornecido separadamente.
4. O push dos arquivos inicia a compilação. Em **Actions**, abra a execução `Compilar Vaga Pronta Android` e, se for concluída com sucesso, baixe o artefato `VagaPronta-Diagnostico-v13-APK`. Extraia o ZIP de artefato e instale `app-debug.apk`.

**Não publique** senha, tokens, credenciais da empresa ou o APK do Bookker original nesse repositório. Nenhuma configuração MSAL empresarial foi inventada.

Se a compilação não for bem-sucedida, consulte o log no GitHub Actions e compartilhe somente o erro, sem segredos.
